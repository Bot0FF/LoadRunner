Action()
{

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(16);

	lr_start_transaction("log_in");

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=body", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=134081.454515998ziQziVtpiVzzzzzHtVDiApiiiQ", ENDITEM, 
		"Name=username", "Value=007", ENDITEM, 
		"Name=password", "Value=password", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=login.x", "Value=51", ENDITEM, 
		"Name=login.y", "Value=9", ENDITEM, 
		LAST);

	lr_end_transaction("log_in",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("itinerary");

	web_url("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("itinerary",LR_AUTO);

	lr_think_time(31);

	lr_start_transaction("remove_ticket");

	web_submit_data("itinerary.pl", 
		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flightID", "Value=0-7-JB", ENDITEM, 
		"Name=2", "Value=on", ENDITEM, 
		"Name=flightID", "Value=210304877-1591-TA", ENDITEM, 
		"Name=flightID", "Value=210304877-2360-TA", ENDITEM, 
		"Name=flightID", "Value=210304877-3129-JB", ENDITEM, 
		"Name=flightID", "Value=210304877-3899-JB", ENDITEM, 
		"Name=flightID", "Value=210305264-4626-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-5412-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-6181-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-6951-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-7720-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-8489-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-9258-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-10028-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-10797-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-11566-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-12335-JB", ENDITEM, 
		"Name=flightID", "Value=86856383-13104-JB", ENDITEM, 
		"Name=flightID", "Value=169556354-13889-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-14671-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-15440-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-16209-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-16978-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-17747-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-18517-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-19286-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-20055-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-20824-JB", ENDITEM, 
		"Name=flightID", "Value=86852249-21594-JB", ENDITEM, 
		"Name=flightID", "Value=86859648-22346-JB", ENDITEM, 
		"Name=flightID", "Value=86859648-23115-JB", ENDITEM, 
		"Name=flightID", "Value=210305264-23857-JB", ENDITEM, 
		"Name=flightID", "Value=210305264-24626-JB", ENDITEM, 
		"Name=flightID", "Value=210305264-25396-JB", ENDITEM, 
		"Name=flightID", "Value=210305264-26165-JB", ENDITEM, 
		"Name=flightID", "Value=210305264-26934-JB", ENDITEM, 
		"Name=flightID", "Value=210311488-27706-JB", ENDITEM, 
		"Name=flightID", "Value=210311488-28475-JB", ENDITEM, 
		"Name=flightID", "Value=210311488-29245-JB", ENDITEM, 
		"Name=flightID", "Value=0-300-JB", ENDITEM, 
		"Name=flightID", "Value=210300020-30812-JB", ENDITEM, 
		"Name=flightID", "Value=210300020-31581-JB", ENDITEM, 
		"Name=flightID", "Value=210300020-32350-JB", ENDITEM, 
		"Name=flightID", "Value=77798-33119-JB", ENDITEM, 
		"Name=flightID", "Value=104855576-33889-JB", ENDITEM, 
		"Name=flightID", "Value=117225952-34671-JB", ENDITEM, 
		"Name=flightID", "Value=156337057-35427-JB", ENDITEM, 
		"Name=flightID", "Value=356966680-36183-JB", ENDITEM, 
		"Name=flightID", "Value=308337063-36978-JB", ENDITEM, 
		"Name=flightID", "Value=362670397-37747-JB", ENDITEM, 
		"Name=flightID", "Value=321670391-38504-JB", ENDITEM, 
		"Name=flightID", "Value=127040767-39286-JB", ENDITEM, 
		"Name=flightID", "Value=237040761-40043-JB", ENDITEM, 
		"Name=flightID", "Value=220818545-40824-JB", ENDITEM, 
		"Name=.cgifields", "Value=33", ENDITEM, 
		"Name=.cgifields", "Value=32", ENDITEM, 
		"Name=.cgifields", "Value=21", ENDITEM, 
		"Name=.cgifields", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=26", ENDITEM, 
		"Name=.cgifields", "Value=17", ENDITEM, 
		"Name=.cgifields", "Value=2", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		"Name=.cgifields", "Value=18", ENDITEM, 
		"Name=.cgifields", "Value=30", ENDITEM, 
		"Name=.cgifields", "Value=16", ENDITEM, 
		"Name=.cgifields", "Value=44", ENDITEM, 
		"Name=.cgifields", "Value=27", ENDITEM, 
		"Name=.cgifields", "Value=25", ENDITEM, 
		"Name=.cgifields", "Value=28", ENDITEM, 
		"Name=.cgifields", "Value=40", ENDITEM, 
		"Name=.cgifields", "Value=20", ENDITEM, 
		"Name=.cgifields", "Value=14", ENDITEM, 
		"Name=.cgifields", "Value=49", ENDITEM, 
		"Name=.cgifields", "Value=24", ENDITEM, 
		"Name=.cgifields", "Value=10", ENDITEM, 
		"Name=.cgifields", "Value=31", ENDITEM, 
		"Name=.cgifields", "Value=35", ENDITEM, 
		"Name=.cgifields", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=53", ENDITEM, 
		"Name=.cgifields", "Value=48", ENDITEM, 
		"Name=.cgifields", "Value=42", ENDITEM, 
		"Name=.cgifields", "Value=22", ENDITEM, 
		"Name=.cgifields", "Value=46", ENDITEM, 
		"Name=.cgifields", "Value=13", ENDITEM, 
		"Name=.cgifields", "Value=23", ENDITEM, 
		"Name=.cgifields", "Value=29", ENDITEM, 
		"Name=.cgifields", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=50", ENDITEM, 
		"Name=.cgifields", "Value=39", ENDITEM, 
		"Name=.cgifields", "Value=36", ENDITEM, 
		"Name=.cgifields", "Value=3", ENDITEM, 
		"Name=.cgifields", "Value=51", ENDITEM, 
		"Name=.cgifields", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=41", ENDITEM, 
		"Name=.cgifields", "Value=12", ENDITEM, 
		"Name=.cgifields", "Value=47", ENDITEM, 
		"Name=.cgifields", "Value=15", ENDITEM, 
		"Name=.cgifields", "Value=52", ENDITEM, 
		"Name=.cgifields", "Value=38", ENDITEM, 
		"Name=.cgifields", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=34", ENDITEM, 
		"Name=.cgifields", "Value=45", ENDITEM, 
		"Name=.cgifields", "Value=37", ENDITEM, 
		"Name=.cgifields", "Value=43", ENDITEM, 
		"Name=.cgifields", "Value=19", ENDITEM, 
		"Name=.cgifields", "Value=5", ENDITEM, 
		"Name=removeFlights.x", "Value=62", ENDITEM, 
		"Name=removeFlights.y", "Value=10", ENDITEM, 
		LAST);

	lr_end_transaction("remove_ticket",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("log_out");

	web_url("SignOff Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("log_out",LR_AUTO);

	return 0;
}